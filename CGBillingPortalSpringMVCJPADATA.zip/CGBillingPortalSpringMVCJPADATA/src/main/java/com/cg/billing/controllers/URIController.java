package com.cg.billing.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.billing.beans.Customer;

@Controller
public class URIController {

	@RequestMapping(value = {"/", "index"})
	public String getIndexPage() {
		return "indexPage";
	}
	
	@RequestMapping("/RegisterDet")
	public String getRegistrationPage() {
		return "RegisterDetails";
	}
	@RequestMapping("/PostpaidDet")
	public String getPostpaidPage() {
		return "PostpaidDetails";
	}
	
	@RequestMapping("/CustDet")
	public String getCustDetails() {
		return "OneCustomerDetails";
	}
	
	@RequestMapping("/AllCustDet")
	public String getAllCustDetails() {
		return "AllCustomerDetails";
	}
	
	@RequestMapping("/PPAccDet")
	public String getPPAccDetails() {
		return "postpaidAccountDetails";
	}
	

	@RequestMapping("/AllPPAccDet")
	public String getAllPPAccDetails() {
		return "allPostpaidAccountDetailsPage";
	}
	
	@RequestMapping("/AllPlanDet")
	public String getAllPlanDetails() {
		return "AllPlanDetailsPage";
	}
	
	@RequestMapping("/BillDet")
	public String getBillDetails() {
		return "BillDetailsSuccessPage";
	}
	
	@RequestMapping("/MonthlyBillDet")
	public String generateMonthlyBillDetails() {
		return "MonthlyBillDetailsSuccessPage";
	}
	
	@RequestMapping("/AllBillDet")
	public String generateAllBillDetails() {
		return "AllBillDetailsSuccessPage";
	}
	
	@RequestMapping("/rmvCustDet")
	public String rmvCustDet() {
		return "CustomerDetailsRemovedSuccessPage";
	}
	
	@RequestMapping("/clsCustPPAcc")
	public String closeCustPP() {
		return "CustomerPPAccClosedSuccessPage";
	}
	
	@RequestMapping("/changePlan")
	public String changeCustPlan() {
		return "CustomerPlanChangedSuccessPage";
	}
	@ModelAttribute
	public Customer getCustomer() {
		return new Customer();
	}
}
